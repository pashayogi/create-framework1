# create-framework
# (C)Copyright 2019 MR.K7C8NG
<br>
tools to make viruses simple
<br>
$ git clone https://github.com/pashayogi/create-framework
<br>
$ cd create-framework
<br>
$ sh install.sh
<br>
<br>
# Simple commands
<br>
vcrt > show options
<br>
<>
REPORT ME BUG ON INSTAGRAM
# Contact
<br>
instagram : @pranata_pasha
<br>
JANGAN DI RECODE 
<br>
# Thanks to
# InDoNeSiA CYBER ErRoR SyStEm
