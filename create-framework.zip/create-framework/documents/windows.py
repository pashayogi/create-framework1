R = '\033[31m' # Red
N = '\033[1;37m' # White
def a():
	print ""+N+""
	print "VIRUS FOR WINDOWS COLLECTIONS"
	print "============================="
	print 
	print "name                                        rank"
	print "----                                        ----\033[31m"
	print "/modules/windows/module_req_eater           normal"
	print "/modules/windows/module_quis                normal"
	print "/modules/windows/module_ugly                normal"
	print "/modules/windows/module_sleepy              normal"
	print "/modules/windows/module_rip                 normal"
	print "/modules/windows/module_koce                normal"
	print "/modules/windows/module_capslock            funny :v"
	print "/modules/windows/module_rdc                 normal"
	print "/modules/windows/module_alay                normal"
	print "/modules/windows/module_zipbomb             low"
	print "/modules/windows/module_cmd                 normal"
	
if __name__ == "__main__":
	a()
